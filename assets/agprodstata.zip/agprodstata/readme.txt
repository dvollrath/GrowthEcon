Data files for "Land Distribution and International Agricultural Productivity"

Files:
agprodols.dta - STATA file for the OLS regressions in table 4
agprodols.do - do-file that replicates the results in table 4
agprodpanel.dta - STATA file for panel regressions in table 6
agprodpanel.do - do-file that replicates the results in table 6

The files were created using STATA version 9.